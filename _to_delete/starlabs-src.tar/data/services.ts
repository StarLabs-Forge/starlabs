// Las cuatro cosas que StarLabs construye — mismas categorías que la fila del
// Hero ("Web · Apps · Sistemas · Productos propios"). Fuente única para el
// resumen en Home, para /servicios y para el footer, evita que diverjan en
// texto o en el link al que apuntan.
export interface Service {
  id: string;
  name: string;
  hook: string;
  description: string;
  // Página propia de esta categoría — la card ya no redirige a /contacto,
  // cada una es puerta de entrada a su propia página (ver App.tsx).
  path: string;
}

export const services: Service[] = [
  {
    id: "web",
    name: "Web",
    hook: "Tu negocio, online.",
    description: "Sitios que convierten.",
    path: "/servicios/web",
  },
  {
    id: "apps",
    name: "Apps",
    hook: "Tu idea, en el bolsillo.",
    description: "Experiencias para tus usuarios.",
    path: "/servicios/apps",
  },
  {
    id: "sistemas",
    name: "Sistemas",
    hook: "Menos trabajo. Más control.",
    description: "Procesos que trabajan contigo.",
    path: "/servicios/sistemas",
  },
  {
    id: "productos",
    name: "Productos propios",
    hook: "Nuestras ideas, hechas realidad.",
    description: "Productos y proyectos que nacen dentro de StarLabs.",
    path: "/productos",
  },
];
